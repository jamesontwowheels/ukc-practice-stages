New functions:

- Pair people
- align times
- time based values
- optional modes
- buy and sell